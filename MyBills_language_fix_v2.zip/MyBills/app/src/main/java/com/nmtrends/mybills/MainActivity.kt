package com.nmtrends.mybills

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nmtrends.mybills.data.datastore.ThemeMode
import com.nmtrends.mybills.di.ServiceLocator
import com.nmtrends.mybills.ui.navigation.AppNav
import com.nmtrends.mybills.ui.theme.MyBillsTheme
import com.nmtrends.mybills.ui.viewmodel.AppSettingsViewModel
import com.nmtrends.mybills.ui.viewmodel.AppSettingsViewModelFactory
import com.nmtrends.mybills.util.AppLanguage
import com.nmtrends.mybills.util.AppLocale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val context = LocalContext.current
            val repo = remember { ServiceLocator.provideRepository(context) }
            val vm: AppSettingsViewModel = viewModel(factory = AppSettingsViewModelFactory(repo))

            val isPremium by vm.isPremium.collectAsState()
            val themeMode by vm.themeMode.collectAsState()
            val notifAsked by vm.notifAsked.collectAsState()

            val appLanguage by vm.appLanguage.collectAsState()
            val languageChosen by vm.languageChosen.collectAsState()

            val effectiveMode = if (isPremium) themeMode else ThemeMode.SYSTEM

            LaunchedEffect(appLanguage) {
                AppLocale.apply(appLanguage)
            }

            // Primer inicio: preguntar idioma antes de pedir notificaciones
if (!languageChosen) {
    AlertDialog(
        onDismissRequest = { /* forzar elección */ },
        title = { Text(stringResource(R.string.language_choose_title)) },
        text = { Text(stringResource(R.string.language_choose_message)) },
        confirmButton = {
            Button(onClick = { vm.setAppLanguage(AppLanguage.EN) }) {
                Text(stringResource(R.string.language_english))
            }
        },
        dismissButton = {
            Button(onClick = { vm.setAppLanguage(AppLanguage.ES) }) {
                Text(stringResource(R.string.language_spanish))
            }
        }
    )
}

// Launcher para permiso de notificaciones (Android 13+)
            val notifLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { _ ->
                // marcamos "ya preguntado" aunque diga NO, para no spamear
                vm.setNotifAsked(true)
            }

            // Pedir permiso solo 1 vez, solo Android 13+, solo si aún no se preguntó
            LaunchedEffect(notifAsked) {
                if (Build.VERSION.SDK_INT >= 33 && !notifAsked) {
                    val granted = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED

                    if (!granted) {
                        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        vm.setNotifAsked(true)
                    }
                }
            }

            // Si no es Premium, forzamos SYSTEM
            LaunchedEffect(isPremium, themeMode) {
                if (!isPremium && themeMode != ThemeMode.SYSTEM) {
                    vm.setThemeMode(ThemeMode.SYSTEM)
                }
            }

            MyBillsTheme(themeMode = effectiveMode) {
                AppNav()
            }
        }
    }
}
