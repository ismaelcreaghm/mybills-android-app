package com.nmtrends.mybills.data.local.dao

import androidx.room.*
import com.nmtrends.mybills.data.local.entity.BillEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BillDao {

    @Query("SELECT * FROM bills ORDER BY sortOrder ASC, dueDateMillis ASC")
    fun observeBills(): Flow<List<BillEntity>>

    @Query("SELECT * FROM bills ORDER BY sortOrder ASC, dueDateMillis ASC")
    suspend fun getAllOnce(): List<BillEntity>

    @Query("SELECT * FROM bills WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): BillEntity?

    @Query("SELECT COUNT(*) FROM bills")
    suspend fun countBills(): Int

    @Query("SELECT MAX(sortOrder) FROM bills")
    suspend fun maxSortOrder(): Int?

    @Query("UPDATE bills SET sortOrder = :order WHERE id = :id")
    suspend fun updateSortOrder(id: Long, order: Int)

    // ✅ Unificado: pagada / no pagada
    @Query("UPDATE bills SET isPaid = :isPaid, paidAtMillis = :paidAtMillis WHERE id = :id")
    suspend fun setPaidState(id: Long, isPaid: Boolean, paidAtMillis: Long?)

    @Insert
    suspend fun insert(bill: BillEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReplace(bill: BillEntity)

    @Update
    suspend fun update(bill: BillEntity)

    @Delete
    suspend fun delete(bill: BillEntity)
}
