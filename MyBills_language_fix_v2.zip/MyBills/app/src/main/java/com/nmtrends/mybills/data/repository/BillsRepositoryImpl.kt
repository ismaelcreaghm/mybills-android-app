package com.nmtrends.mybills.data.repository

import android.content.Context
import com.nmtrends.mybills.data.datastore.SettingsStore
import com.nmtrends.mybills.data.datastore.ThemeMode
import com.nmtrends.mybills.data.local.dao.BillDao
import com.nmtrends.mybills.data.local.dao.IncomeDao
import com.nmtrends.mybills.data.local.entity.BillEntity
import com.nmtrends.mybills.data.local.entity.IncomeEntity
import com.nmtrends.mybills.notifications.ReminderScheduler
import com.nmtrends.mybills.util.AppLanguage
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.Calendar
import java.util.concurrent.TimeUnit

class BillsRepositoryImpl(
    private val context: Context,
    private val billDao: BillDao,
    private val incomeDao: IncomeDao,
    private val settingsStore: SettingsStore
) : BillsRepository {

    override val billsFlow = billDao.observeBills()
    override val incomeFlow = incomeDao.observeIncome()
    override val premiumFlow = settingsStore.premiumFlow
    override val themeModeFlow = settingsStore.themeModeFlow

    override val appLanguageFlow = settingsStore.languageTagFlow.map { tag ->
        when (tag) {
            AppLanguage.ES.tag -> AppLanguage.ES
            else -> AppLanguage.EN
        }
    }

    override val languageChosenFlow = settingsStore.languageChosenFlow

    override suspend fun setAppLanguage(language: AppLanguage) {
        settingsStore.setLanguageTag(language.tag)
    }

    override val notifAskedFlow = settingsStore.notifAskedFlow
    override suspend fun setNotifAsked(asked: Boolean) = settingsStore.setNotifAsked(asked)

    override suspend fun addBill(title: String, amount: Double, dueDateMillis: Long): Result<Long> {
        return addBill(
            title = title,
            amount = amount,
            dueDateMillis = dueDateMillis,
            note = null,
            reminderAtMillis = null,
            isMonthly = true,
            dayOfMonth = Calendar.getInstance().get(Calendar.DAY_OF_MONTH),
            reminderDaysBefore = null,
            reminderHour = null,
            reminderMinute = null
        )
    }

    override suspend fun addBill(
        title: String,
        amount: Double,
        dueDateMillis: Long,
        note: String?,
        reminderAtMillis: Long?,
        isMonthly: Boolean,
        dayOfMonth: Int?,
        reminderDaysBefore: Int?,
        reminderHour: Int?,
        reminderMinute: Int?
    ): Result<Long> {
        val isPremium = premiumFlow.first()
        val limit = if (isPremium) 16 else 10
        val count = billDao.countBills()
        if (count >= limit) return Result.failure(IllegalStateException("LIMIT_REACHED"))

        val finalTitle = title.trim()
        if (finalTitle.isBlank()) return Result.failure(IllegalArgumentException("Título vacío"))
        if (amount <= 0.0) return Result.failure(IllegalArgumentException("Monto inválido"))

        val finalNote = if (isPremium) note?.trim().takeIf { !it.isNullOrBlank() } else null

        val finalDueDateMillis = if (isMonthly) {
            computeNextMonthlyDueDateMillis((dayOfMonth ?: 1).coerceIn(1, 31))
        } else {
            dueDateMillis
        }

        val rawReminder = computeFinalReminderAtMillis(
            isPremium = isPremium,
            finalDueDateMillis = finalDueDateMillis,
            reminderAtMillis = reminderAtMillis,
            reminderDaysBefore = reminderDaysBefore,
            reminderHour = reminderHour,
            reminderMinute = reminderMinute
        )

        val finalReminderAtMillis = normalizeReminderAt(
            dueAtMillis = finalDueDateMillis,
            remindAtMillis = rawReminder,
            nowMillis = System.currentTimeMillis()
        )

        val nextOrder = (billDao.maxSortOrder() ?: 0) + 1

        val id = billDao.insert(
            BillEntity(
                title = finalTitle,
                amount = amount,
                dueDateMillis = finalDueDateMillis,
                note = finalNote,
                reminderAtMillis = finalReminderAtMillis,
                isMonthly = isMonthly,
                dayOfMonth = if (isMonthly) (dayOfMonth ?: 1).coerceIn(1, 31) else null,
                reminderDaysBefore = if (isPremium) reminderDaysBefore else null,
                reminderHour = if (isPremium) reminderHour else null,
                reminderMinute = if (isPremium) reminderMinute else null,
                sortOrder = nextOrder,
                isPaid = false,
                paidAtMillis = null,
                category = null
            )
        )

        if (finalReminderAtMillis != null) {
            ReminderScheduler.scheduleAt(context, id, finalTitle, amount, finalReminderAtMillis)
        }

        return Result.success(id)
    }

    override suspend fun updateBill(
        id: Long,
        title: String,
        amount: Double,
        dueDateMillis: Long,
        note: String?,
        reminderAtMillis: Long?,
        isMonthly: Boolean,
        dayOfMonth: Int?,
        reminderDaysBefore: Int?,
        reminderHour: Int?,
        reminderMinute: Int?
    ): Result<Unit> {
        val current =
            billDao.getById(id) ?: return Result.failure(IllegalStateException("No existe"))

        val isPremium = premiumFlow.first()
        val finalTitle = title.trim()
        if (finalTitle.isBlank()) return Result.failure(IllegalArgumentException("Título vacío"))
        if (amount <= 0.0) return Result.failure(IllegalArgumentException("Monto inválido"))

        val finalNote = if (isPremium) note?.trim().takeIf { !it.isNullOrBlank() } else null

        val finalDueDateMillis = if (isMonthly) {
            computeNextMonthlyDueDateMillis((dayOfMonth ?: 1).coerceIn(1, 31))
        } else {
            dueDateMillis
        }

        // Si NO es mensual y está pagada => sin recordatorio
        val shouldHaveReminder = isMonthly || !current.isPaid

        val rawReminder =
            if (!shouldHaveReminder) null
            else computeFinalReminderAtMillis(
                isPremium = isPremium,
                finalDueDateMillis = finalDueDateMillis,
                reminderAtMillis = reminderAtMillis,
                reminderDaysBefore = reminderDaysBefore,
                reminderHour = reminderHour,
                reminderMinute = reminderMinute
            )

        val finalReminderAtMillis = normalizeReminderAt(
            dueAtMillis = finalDueDateMillis,
            remindAtMillis = rawReminder,
            nowMillis = System.currentTimeMillis()
        )

        val updated = current.copy(
            title = finalTitle,
            amount = amount,
            dueDateMillis = finalDueDateMillis,
            note = finalNote,
            reminderAtMillis = finalReminderAtMillis,
            isMonthly = isMonthly,
            dayOfMonth = if (isMonthly) (dayOfMonth ?: 1).coerceIn(1, 31) else null,
            reminderDaysBefore = if (isPremium) reminderDaysBefore else null,
            reminderHour = if (isPremium) reminderHour else null,
            reminderMinute = if (isPremium) reminderMinute else null
        )

        billDao.update(updated)

        // Reprogramar limpio
        ReminderScheduler.cancel(context, id)
        if (updated.reminderAtMillis != null && (updated.isMonthly || !updated.isPaid)) {
            ReminderScheduler.scheduleAt(
                context,
                id,
                updated.title,
                updated.amount,
                updated.reminderAtMillis
            )
        }

        return Result.success(Unit)
    }

    override suspend fun markPaid(id: Long): Result<Unit> {
        val current =
            billDao.getById(id) ?: return Result.failure(IllegalStateException("No existe"))
        val paidAt = System.currentTimeMillis()

        // Mensual: marca pagada + avanza próximo vencimiento (y recalcula recordatorio)
        if (current.isMonthly) {
            val dom = (current.dayOfMonth ?: 1).coerceIn(1, 31)
            val nextDue = computeNextMonthlyDueDateMillis(dom)

            val isPremium = premiumFlow.first()
            val rawNextReminder = computeFinalReminderAtMillis(
                isPremium = isPremium,
                finalDueDateMillis = nextDue,
                reminderAtMillis = null,
                reminderDaysBefore = current.reminderDaysBefore,
                reminderHour = current.reminderHour,
                reminderMinute = current.reminderMinute
            )

            val nextReminder = normalizeReminderAt(
                dueAtMillis = nextDue,
                remindAtMillis = rawNextReminder,
                nowMillis = System.currentTimeMillis()
            )

            val updated = current.copy(
                isPaid = true,
                paidAtMillis = paidAt,
                dueDateMillis = nextDue,
                reminderAtMillis = nextReminder
            )

            billDao.update(updated)

            ReminderScheduler.cancel(context, id)
            if (nextReminder != null) {
                ReminderScheduler.scheduleAt(
                    context,
                    id,
                    updated.title,
                    updated.amount,
                    nextReminder
                )
            }

            return Result.success(Unit)
        }

        // No mensual
        billDao.setPaidState(id, isPaid = true, paidAtMillis = paidAt)
        ReminderScheduler.cancel(context, id)
        return Result.success(Unit)
    }

    override suspend fun markUnpaid(id: Long): Result<Unit> {
        val current =
            billDao.getById(id) ?: return Result.failure(IllegalStateException("No existe"))

        val isPremium = premiumFlow.first()
        val raw = computeFinalReminderAtMillis(
            isPremium = isPremium,
            finalDueDateMillis = current.dueDateMillis,
            reminderAtMillis = null,
            reminderDaysBefore = current.reminderDaysBefore,
            reminderHour = current.reminderHour,
            reminderMinute = current.reminderMinute
        )

        val remindAt = normalizeReminderAt(
            dueAtMillis = current.dueDateMillis,
            remindAtMillis = raw,
            nowMillis = System.currentTimeMillis()
        )

        billDao.setPaidState(id, isPaid = false, paidAtMillis = null)

        ReminderScheduler.cancel(context, id)
        if (remindAt != null) {
            ReminderScheduler.scheduleAt(context, id, current.title, current.amount, remindAt)
        }

        return Result.success(Unit)
    }

    override suspend fun restoreBill(bill: BillEntity): Result<Unit> {
        billDao.insertReplace(bill)

        ReminderScheduler.cancel(context, bill.id)
        if (bill.reminderAtMillis != null && (bill.isMonthly || !bill.isPaid)) {
            ReminderScheduler.scheduleAt(
                context,
                bill.id,
                bill.title,
                bill.amount,
                bill.reminderAtMillis
            )
        }

        return Result.success(Unit)
    }

    override suspend fun swapSortOrder(idA: Long, orderA: Int, idB: Long, orderB: Int) {
        billDao.updateSortOrder(idA, orderB)
        billDao.updateSortOrder(idB, orderA)
    }

    override suspend fun deleteBill(bill: BillEntity) {
        billDao.delete(bill)
        ReminderScheduler.cancel(context, bill.id)
    }

    override suspend fun setIncome(monthlyIncome: Double) {
        incomeDao.upsert(IncomeEntity(monthlyIncome = monthlyIncome))
    }

    override suspend fun setPremium(enabled: Boolean) {
        settingsStore.setPremium(enabled)
        refreshAndRescheduleAll()
    }

    override suspend fun setThemeMode(mode: ThemeMode) {
        settingsStore.setThemeMode(mode)
    }

    override suspend fun refreshAndRescheduleAll() {
        val isPremium = premiumFlow.first()
        val now = System.currentTimeMillis()

        val all = billDao.getAllOnce()

        // Cancelar todo primero
        for (b in all) {
            ReminderScheduler.cancel(context, b.id)
        }

        for (b in all) {
            var updated = b

            // Si mensual y quedó atrás, empuja vencimiento
            if (updated.isMonthly) {
                val dom = (updated.dayOfMonth ?: 1).coerceIn(1, 31)
                val nextDue = computeNextMonthlyDueDateMillis(dom)
                if (updated.dueDateMillis <= now) {
                    updated = updated.copy(dueDateMillis = nextDue)
                }
            }

            val shouldSchedule = updated.isMonthly || !updated.isPaid

            val rawReminder = if (!shouldSchedule) null else computeFinalReminderAtMillis(
                isPremium = isPremium,
                finalDueDateMillis = updated.dueDateMillis,
                reminderAtMillis = null,
                reminderDaysBefore = updated.reminderDaysBefore,
                reminderHour = updated.reminderHour,
                reminderMinute = updated.reminderMinute
            )

            val newReminder = normalizeReminderAt(
                dueAtMillis = updated.dueDateMillis,
                remindAtMillis = rawReminder,
                nowMillis = now
            )

            if (updated.reminderAtMillis != newReminder) {
                updated = updated.copy(reminderAtMillis = newReminder)
            }

            if (updated != b) {
                billDao.update(updated)
            }

            if (shouldSchedule && updated.reminderAtMillis != null && updated.reminderAtMillis!! > now) {
                ReminderScheduler.scheduleAt(
                    context,
                    updated.id,
                    updated.title,
                    updated.amount,
                    updated.reminderAtMillis!!
                )
            }
        }
    }

    /**
     * Si el recordatorio calculado quedó en el pasado:
     * - si el vencimiento todavía está en el futuro => reubica el recordatorio al vencimiento
     * - si el vencimiento ya pasó => no programa nada
     */
    private fun normalizeReminderAt(
        dueAtMillis: Long,
        remindAtMillis: Long?,
        nowMillis: Long
    ): Long? {
        if (remindAtMillis == null) return null
        if (remindAtMillis > nowMillis) return remindAtMillis

        // Se “perdió” el día-antes (o el usuario creó tarde). Programar al vencimiento si aún falta.
        return if (dueAtMillis > nowMillis) dueAtMillis else null
    }

    private fun computeNextMonthlyDueDateMillis(dayOfMonth: Int): Long {
        val now = Calendar.getInstance()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 9)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        fun setClampedDay(c: Calendar, d: Int) {
            val max = c.getActualMaximum(Calendar.DAY_OF_MONTH)
            c.set(Calendar.DAY_OF_MONTH, minOf(d, max))
        }

        setClampedDay(cal, dayOfMonth)
        if (cal.timeInMillis <= now.timeInMillis) {
            cal.add(Calendar.MONTH, 1)
            setClampedDay(cal, dayOfMonth)
        }
        return cal.timeInMillis
    }

    private fun computeFinalReminderAtMillis(
        isPremium: Boolean,
        finalDueDateMillis: Long,
        reminderAtMillis: Long?,
        reminderDaysBefore: Int?,
        reminderHour: Int?,
        reminderMinute: Int?
    ): Long? {

        val now = System.currentTimeMillis()

        fun nowPlus5MinRounded(): Long {
            val cal = Calendar.getInstance().apply {
                timeInMillis = now + TimeUnit.MINUTES.toMillis(5)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            return cal.timeInMillis
        }

        fun todayAtNine(): Long {
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 9)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            return cal.timeInMillis
        }

        // Estándar: 1 día antes (por cómo guardas dueDate, normalmente cae a 9:00 AM)
        val standard = finalDueDateMillis - TimeUnit.DAYS.toMillis(1)

        if (!isPremium) {
            // Si el estándar queda en el pasado (ej: vencimiento "hoy"), lo movemos a hoy 9:00 AM si no ha pasado.
            if (standard > now) return standard

            val nine = todayAtNine()
            return if (nine > now) nine else nowPlus5MinRounded()
        }

        // Premium: calcula según configuración, pero si cae en pasado => ahora + 5 min
        val computed = when {
            reminderAtMillis != null -> reminderAtMillis

            reminderDaysBefore != null && reminderHour != null && reminderMinute != null -> {
                val cal = Calendar.getInstance().apply {
                    timeInMillis = finalDueDateMillis
                    add(Calendar.DAY_OF_MONTH, -reminderDaysBefore.coerceIn(0, 60))
                    set(Calendar.HOUR_OF_DAY, reminderHour.coerceIn(0, 23))
                    set(Calendar.MINUTE, reminderMinute.coerceIn(0, 59))
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                cal.timeInMillis
            }

            else -> standard
        }

        return if (computed > now) computed else nowPlus5MinRounded()
    }
}