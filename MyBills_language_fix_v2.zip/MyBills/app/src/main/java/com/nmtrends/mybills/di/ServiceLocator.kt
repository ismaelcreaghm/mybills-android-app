package com.nmtrends.mybills.di

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.nmtrends.mybills.data.datastore.SettingsStore
import com.nmtrends.mybills.data.local.db.AppDatabase
import com.nmtrends.mybills.data.repository.BillsRepository
import com.nmtrends.mybills.data.repository.BillsRepositoryImpl

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE bills ADD COLUMN note TEXT")
    }
}

private val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE bills ADD COLUMN reminderAtMillis INTEGER")
    }
}

private val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE bills ADD COLUMN isMonthly INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE bills ADD COLUMN dayOfMonth INTEGER")
        db.execSQL("ALTER TABLE bills ADD COLUMN reminderDaysBefore INTEGER")
        db.execSQL("ALTER TABLE bills ADD COLUMN reminderHour INTEGER")
        db.execSQL("ALTER TABLE bills ADD COLUMN reminderMinute INTEGER")
    }
}

private val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE bills ADD COLUMN sortOrder INTEGER NOT NULL DEFAULT 0")
    }
}

// v5 -> v6: estado pagado + fecha pagado + categoría
private val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE bills ADD COLUMN isPaid INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE bills ADD COLUMN paidAtMillis INTEGER")
        db.execSQL("ALTER TABLE bills ADD COLUMN category TEXT")
    }
}

object ServiceLocator {

    @Volatile private var db: AppDatabase? = null
    @Volatile private var repo: BillsRepository? = null

    fun provideDatabase(context: Context): AppDatabase {
        val appContext = context.applicationContext
        return db ?: synchronized(this) {
            db ?: Room.databaseBuilder(
                appContext,
                AppDatabase::class.java,
                "mybills.db"
            )
                .addMigrations(
                    MIGRATION_1_2,
                    MIGRATION_2_3,
                    MIGRATION_3_4,
                    MIGRATION_4_5,
                    MIGRATION_5_6
                )
                .build()
                .also { db = it }
        }
    }

    fun provideRepository(context: Context): BillsRepository {
        return repo ?: synchronized(this) {
            val appContext = context.applicationContext
            val database = provideDatabase(appContext)
            val settings = SettingsStore(appContext)

            BillsRepositoryImpl(
                context = appContext,
                billDao = database.billDao(),
                incomeDao = database.incomeDao(),
                settingsStore = settings
            ).also { repo = it }
        }
    }
}
