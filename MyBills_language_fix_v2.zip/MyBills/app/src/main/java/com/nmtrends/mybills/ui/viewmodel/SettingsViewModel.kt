package com.nmtrends.mybills.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nmtrends.mybills.data.datastore.ThemeMode
import com.nmtrends.mybills.data.repository.BillsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val repo: BillsRepository) : ViewModel() {

    val isPremium: StateFlow<Boolean> =
        repo.premiumFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val themeMode: StateFlow<ThemeMode> =
        repo.themeModeFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.SYSTEM)

    fun setPremium(value: Boolean) {
        viewModelScope.launch { repo.setPremium(value) }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { repo.setThemeMode(mode) }
    }
}
