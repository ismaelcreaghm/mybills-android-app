package com.nmtrends.mybills.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.max

data class DonutSlice(
    val value: Double,
    val color: Color
)

data class DonutLegendItem(
    val label: String,
    val value: Double,
    val color: Color
)

@Composable
fun DonutChartCard(
    centerMain: String,
    centerSub: String,
    slices: List<DonutSlice>,
    legendItems: List<DonutLegendItem>,
    modifier: Modifier = Modifier,
    chartSize: Dp = 170.dp,
    strokeWidth: Dp = 18.dp
) {
    val total = remember(slices) { max(0.0001, slices.sumOf { max(0.0, it.value) }) }

    // ✅ Capturar colores fuera del Canvas
    val ringBaseColor = MaterialTheme.colorScheme.surfaceVariant
    val subTextColor = MaterialTheme.colorScheme.onSurfaceVariant

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(chartSize),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.matchParentSize()) {
                val stroke = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round)

                // Anillo base
                drawArc(
                    color = ringBaseColor,
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    style = stroke
                )

                var start = -90f
                slices
                    .filter { it.value > 0.0 }
                    .forEach { s ->
                        val sweep = (s.value / total * 360f).toFloat()
                        drawArc(
                            color = s.color,
                            startAngle = start,
                            sweepAngle = sweep,
                            useCenter = false,
                            style = stroke
                        )
                        start += sweep
                    }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(centerMain, style = MaterialTheme.typography.titleLarge)
                Text(centerSub, style = MaterialTheme.typography.bodySmall, color = subTextColor)
            }
        }

        Spacer(Modifier.width(14.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            legendItems.forEach { item ->
                LegendRow(
                    color = item.color,
                    label = item.label,
                    valueText = item.value
                )
            }
        }
    }
}

@Composable
private fun LegendRow(color: Color, label: String, valueText: Double) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Surface(
            color = color,
            shape = CircleShape,
            modifier = Modifier.size(10.dp)
        ) {}

        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Text(
            text = money(valueText),
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

private fun money(v: Double): String {
    return "$" + String.format(java.util.Locale.US, "%.2f", v)
}
