package com.nmtrends.mybills.ui.screens.bills

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nmtrends.mybills.R
import com.nmtrends.mybills.data.local.entity.BillEntity
import com.nmtrends.mybills.di.ServiceLocator
import com.nmtrends.mybills.ui.viewmodel.BillsViewModel
import com.nmtrends.mybills.ui.viewmodel.BillsViewModelFactory
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun BillsScreen() {
    val context = LocalContext.current
    val repo = remember { ServiceLocator.provideRepository(context) }
    val vm: BillsViewModel = viewModel(factory = BillsViewModelFactory(repo))

    val bills by vm.bills.collectAsState()
    val isPremium by vm.isPremium.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var editBill by remember { mutableStateOf<BillEntity?>(null) }

    var confirmDeleteBill by remember { mutableStateOf<BillEntity?>(null) }
    var lastDeleted by remember { mutableStateOf<BillEntity?>(null) }
    var undoRequest by remember { mutableStateOf(false) }

    var snackbarMsg by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    // ✅ Strings leídos dentro de @Composable
    val sBillDeleted = stringResource(R.string.bill_deleted)
    val sUndo = stringResource(R.string.undo)

    LaunchedEffect(snackbarMsg) {
        snackbarMsg?.let {
            snackbarHostState.showSnackbar(it)
            snackbarMsg = null
        }
    }

    // ✅ Undo snackbar
    LaunchedEffect(undoRequest) {
        if (!undoRequest) return@LaunchedEffect

        val deleted = lastDeleted
        if (deleted == null) {
            undoRequest = false
            return@LaunchedEffect
        }

        val result = snackbarHostState.showSnackbar(
            message = sBillDeleted,
            actionLabel = sUndo,
            withDismissAction = true
        )

        if (result == SnackbarResult.ActionPerformed) {
            vm.undoDelete(deleted) { msg -> snackbarMsg = msg }
        }

        undoRequest = false
        lastDeleted = null
    }

    val limit = if (isPremium) 16 else 10
    val totalExpenses = remember(bills) { bills.filter { !it.isPaid }.sumOf { it.amount } }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) { Text("+") }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text(
                stringResource(R.string.bills_title),
                style = MaterialTheme.typography.headlineSmall
            )
            Spacer(Modifier.height(8.dp))

            Text(stringResource(R.string.limit, bills.size, limit))
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.pending_expenses, totalExpenses.toMoney()))

            Spacer(Modifier.height(12.dp))

            if (bills.isEmpty()) {
                Text(stringResource(R.string.empty_bills))
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(bills, key = { _, b -> b.id }) { index, bill ->
                        BillRow(
                            bill = bill,
                            isPremium = isPremium,
                            canMoveUp = isPremium && index > 0,
                            canMoveDown = isPremium && index < bills.lastIndex,
                            onMoveUp = { vm.moveBill(bill, -1, bills) { msg -> snackbarMsg = msg } },
                            onMoveDown = { vm.moveBill(bill, +1, bills) { msg -> snackbarMsg = msg } },
                            onEdit = { editBill = bill },
                            onTogglePaid = {
                                if (bill.isPaid) vm.markUnpaid(bill) { msg -> snackbarMsg = msg }
                                else vm.markPaid(bill) { msg -> snackbarMsg = msg }
                            },
                            onDelete = { confirmDeleteBill = bill }
                        )
                    }
                }
            }
        }
    }

    // ✅ Confirmación al borrar
    confirmDeleteBill?.let { bill ->
        AlertDialog(
            onDismissRequest = { confirmDeleteBill = null },
            title = { Text(stringResource(R.string.delete_bill_title)) },
            text = { Text(stringResource(R.string.delete_bill_confirm, bill.title)) },
            confirmButton = {
                Button(onClick = {
                    confirmDeleteBill = null
                    lastDeleted = bill
                    vm.deleteBill(bill) { msg -> snackbarMsg = msg }
                    undoRequest = true
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDeleteBill = null }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    // ✅ Add
    if (showAddDialog) {
        AddOrEditBillDialog(
            titleDialog = stringResource(R.string.add_bill_title),
            isPremium = isPremium,
            initial = null,
            onDismiss = { showAddDialog = false },
            onSave = { payload ->
                vm.addBill(
                    title = payload.title,
                    amount = payload.amount,
                    dueDateMillis = payload.dueDateMillis,
                    note = payload.note,
                    reminderAtMillis = payload.reminderAtMillis,
                    isMonthly = payload.isMonthly,
                    dayOfMonth = payload.dayOfMonth,
                    reminderDaysBefore = payload.reminderDaysBefore,
                    reminderHour = payload.reminderHour,
                    reminderMinute = payload.reminderMinute,
                    onLimitReached = { snackbarMsg = "Limit reached" }, // opcional
                    onError = { msg -> snackbarMsg = msg }
                )
                showAddDialog = false
            }
        )
    }

    // ✅ Edit
    editBill?.let { bill ->
        AddOrEditBillDialog(
            titleDialog = stringResource(R.string.edit_bill_title),
            isPremium = isPremium,
            initial = bill,
            onDismiss = { editBill = null },
            onSave = { payload ->
                vm.updateBill(
                    id = bill.id,
                    title = payload.title,
                    amount = payload.amount,
                    dueDateMillis = payload.dueDateMillis,
                    note = payload.note,
                    reminderAtMillis = payload.reminderAtMillis,
                    isMonthly = payload.isMonthly,
                    dayOfMonth = payload.dayOfMonth,
                    reminderDaysBefore = payload.reminderDaysBefore,
                    reminderHour = payload.reminderHour,
                    reminderMinute = payload.reminderMinute,
                    onError = { msg -> snackbarMsg = msg }
                )
                editBill = null
            }
        )
    }
}

@Composable
private fun BillRow(
    bill: BillEntity,
    isPremium: Boolean,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onEdit: () -> Unit,
    onTogglePaid: () -> Unit,
    onDelete: () -> Unit
) {
    val sdfDate = remember { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()) }
    val sdfTime = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }

    val dueLabel = remember(bill.dueDateMillis) { sdfDate.format(bill.dueDateMillis) }
    val reminderTimeLabel = remember(bill.reminderAtMillis) {
        bill.reminderAtMillis?.let { sdfTime.format(it) }
    }

    val typeLabel = if (bill.isMonthly) {
        "${stringResource(R.string.monthly)} (${bill.dayOfMonth ?: "?"})"
    } else {
        stringResource(R.string.one_time_desc)
    }

    Card {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {

            // ✅ FILA SUPERIOR: Título alineado con Paid/Unpaid + Edit/Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = bill.title,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(Modifier.width(8.dp))

                FilterChip(
                    selected = bill.isPaid,
                    onClick = onTogglePaid,
                    label = {
                        Text(
                            if (bill.isPaid) stringResource(R.string.paid)
                            else stringResource(R.string.unpaid)
                        )
                    }
                )

                IconButton(onClick = onEdit) {
                    Icon(
                        imageVector = Icons.Filled.Edit,
                        contentDescription = stringResource(R.string.edit)
                    )
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = stringResource(R.string.delete)
                    )
                }
            }

            // ✅ FILA INFERIOR: Izquierda detalles + Derecha (Monthly/One-time vertical y flechas debajo)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {

                // ---- Izquierda: detalles ----
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        stringResource(R.string.amount, bill.amount.toMoney()),
                        style = MaterialTheme.typography.bodySmall
                    )

                    Text(
                        if (bill.isMonthly) stringResource(R.string.next_payment, dueLabel)
                        else stringResource(R.string.due_date, dueLabel),
                        style = MaterialTheme.typography.bodySmall
                    )

                    // Reminder
                    val shouldShowReminder = bill.isMonthly || !bill.isPaid
                    if (shouldShowReminder) {
                        if (isPremium) {
                            Text(
                                text = stringResource(
                                    R.string.reminder_label,
                                    reminderTimeLabel ?: stringResource(R.string.reminder_not_defined)
                                ),
                                style = MaterialTheme.typography.bodySmall
                            )
                        } else {
                            val base = stringResource(R.string.reminder_standard_label)
                            val line = if (reminderTimeLabel != null) "$base ($reminderTimeLabel)" else base
                            Text(line, style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    // Status (solo dentro del card)
                    if (bill.isPaid) {
                        Text(
                            text = stringResource(R.string.status_paid),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    // Nota (solo dentro del card)
                    if (isPremium && !bill.note.isNullOrBlank()) {
                        Text(
                            text = "${stringResource(R.string.note_premium)}: ${bill.note}",
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(Modifier.width(10.dp))

                // ---- Derecha: tipo + flechas en vertical ----
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = typeLabel,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (isPremium) {
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(onClick = onMoveUp, enabled = canMoveUp) {
                                Icon(Icons.Filled.ArrowUpward, contentDescription = "Move up")
                            }
                            IconButton(onClick = onMoveDown, enabled = canMoveDown) {
                                Icon(Icons.Filled.ArrowDownward, contentDescription = "Move down")
                            }
                        }
                    }
                }
            }
        }
    }
}



private data class BillPayload(
    val title: String,
    val amount: Double,
    val dueDateMillis: Long,
    val note: String?,
    val reminderAtMillis: Long?,
    val isMonthly: Boolean,
    val dayOfMonth: Int?,
    val reminderDaysBefore: Int?,
    val reminderHour: Int?,
    val reminderMinute: Int?
)

@Composable
private fun AddOrEditBillDialog(
    titleDialog: String,
    isPremium: Boolean,
    initial: BillEntity?,
    onDismiss: () -> Unit,
    onSave: (BillPayload) -> Unit
) {
    val context = LocalContext.current

    var title by remember { mutableStateOf(initial?.title ?: "") }
    var amountText by remember { mutableStateOf(initial?.amount?.toString() ?: "") }

    var isMonthly by remember { mutableStateOf(initial?.isMonthly ?: true) }

    val now = remember { Calendar.getInstance() }
    var dayOfMonthText by remember {
        mutableStateOf((initial?.dayOfMonth ?: now.get(Calendar.DAY_OF_MONTH)).toString())
    }

    val cal = remember { Calendar.getInstance() }
    var dueDateMillis by remember { mutableStateOf(initial?.dueDateMillis ?: cal.timeInMillis) }

    var note by remember { mutableStateOf(initial?.note ?: "") }

    var daysBeforeText by remember { mutableStateOf((initial?.reminderDaysBefore ?: 1).toString()) }
    var reminderHour by remember { mutableStateOf(initial?.reminderHour ?: 9) }
    var reminderMinute by remember { mutableStateOf(initial?.reminderMinute ?: 0) }

    val sdfDate = remember { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()) }
    val sdfTime = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }

    val dueLabel = remember(dueDateMillis) { sdfDate.format(dueDateMillis) }
    val timeLabel = remember(reminderHour, reminderMinute) {
        val tmp = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, reminderHour)
            set(Calendar.MINUTE, reminderMinute)
        }
        sdfTime.format(tmp.timeInMillis)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(titleDialog) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(stringResource(R.string.bill_title_field)) },
                    singleLine = true
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text(stringResource(R.string.bill_amount_field)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(stringResource(R.string.monthly))
                        Text(
                            if (isMonthly) stringResource(R.string.monthly_desc)
                            else stringResource(R.string.one_time_desc),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = isMonthly, onCheckedChange = { isMonthly = it })
                }

                if (isMonthly) {
                    OutlinedTextField(
                        value = dayOfMonthText,
                        onValueChange = { input -> dayOfMonthText = input.filter { it.isDigit() }.take(2) },
                        label = { Text(stringResource(R.string.day_of_month)) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    Text(stringResource(R.string.example_day), style = MaterialTheme.typography.bodySmall)
                } else {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(stringResource(R.string.due_date, dueLabel))
                        TextButton(onClick = {
                            val c = Calendar.getInstance().apply { timeInMillis = dueDateMillis }
                            DatePickerDialog(
                                context,
                                { _, year, month, day ->
                                    val chosen = Calendar.getInstance().apply {
                                        set(Calendar.YEAR, year)
                                        set(Calendar.MONTH, month)
                                        set(Calendar.DAY_OF_MONTH, day)
                                        set(Calendar.HOUR_OF_DAY, 9)
                                        set(Calendar.MINUTE, 0)
                                        set(Calendar.SECOND, 0)
                                        set(Calendar.MILLISECOND, 0)
                                    }
                                    dueDateMillis = chosen.timeInMillis
                                },
                                c.get(Calendar.YEAR),
                                c.get(Calendar.MONTH),
                                c.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        }) { Text(stringResource(R.string.change)) }
                    }
                }

                if (isPremium) {
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text(stringResource(R.string.note_premium)) },
                        minLines = 2,
                        maxLines = 4
                    )
                } else {
                    Text(
                        stringResource(R.string.notes_premium_only),
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Divider()

                if (isPremium) {
                    Text(
                        stringResource(R.string.reminder_premium_title),
                        style = MaterialTheme.typography.titleSmall
                    )

                    OutlinedTextField(
                        value = daysBeforeText,
                        onValueChange = { input -> daysBeforeText = input.filter { it.isDigit() }.take(2) },
                        label = { Text(stringResource(R.string.days_before)) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(stringResource(R.string.time, timeLabel))
                        TextButton(onClick = {
                            TimePickerDialog(
                                context,
                                { _, hour, minute ->
                                    reminderHour = hour
                                    reminderMinute = minute
                                },
                                reminderHour,
                                reminderMinute,
                                false
                            ).show()
                        }) { Text(stringResource(R.string.change)) }
                    }
                } else {
                    Text(stringResource(R.string.reminder_standard), style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val amount = amountText.replace(",", ".").toDoubleOrNull() ?: return@Button
                if (title.trim().isBlank()) return@Button
                if (amount <= 0.0) return@Button

                val dom =
                    if (isMonthly) (dayOfMonthText.toIntOrNull() ?: now.get(Calendar.DAY_OF_MONTH)).coerceIn(1, 31)
                    else null

                val daysBefore =
                    if (isPremium) (daysBeforeText.toIntOrNull() ?: 1).coerceIn(0, 60)
                    else null

                val hour = if (isPremium) reminderHour else null
                val minute = if (isPremium) reminderMinute else null

                onSave(
                    BillPayload(
                        title = title.trim(),
                        amount = amount,
                        dueDateMillis = dueDateMillis,
                        note = if (isPremium) note.trim().takeIf { it.isNotBlank() } else null,
                        reminderAtMillis = null, // repo calcula
                        isMonthly = isMonthly,
                        dayOfMonth = dom,
                        reminderDaysBefore = daysBefore,
                        reminderHour = hour,
                        reminderMinute = minute
                    )
                )
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}

private fun Double.toMoney(): String =
    "$" + String.format(Locale.US, "%.2f", this)
