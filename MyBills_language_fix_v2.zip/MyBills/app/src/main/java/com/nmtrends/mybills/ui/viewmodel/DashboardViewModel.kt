package com.nmtrends.mybills.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nmtrends.mybills.data.repository.BillsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DashboardState(
    val income: Double = 0.0,
    val expenses: Double = 0.0,
    val remaining: Double = 0.0,
    val isPremium: Boolean = false
)

class DashboardViewModel(private val repo: BillsRepository) : ViewModel() {

    val state: StateFlow<DashboardState> =
        combine(
            repo.incomeFlow,
            repo.billsFlow,
            repo.premiumFlow
        ) { incomeEntity, bills, premium ->

            val income = incomeEntity?.monthlyIncome ?: 0.0
            val expenses = bills.sumOf { it.amount }
            val remaining = income - expenses

            DashboardState(
                income = income,
                expenses = expenses,
                remaining = remaining,
                isPremium = premium
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = DashboardState()
        )

    fun setIncome(value: Double) {
        viewModelScope.launch {
            repo.setIncome(value)
        }
    }
}
