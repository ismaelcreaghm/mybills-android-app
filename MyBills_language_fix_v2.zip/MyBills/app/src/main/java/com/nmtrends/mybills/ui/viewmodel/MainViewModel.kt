package com.nmtrends.mybills.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nmtrends.mybills.data.repository.BillsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit



class MainViewModel(private val repo: BillsRepository) : ViewModel() {

    val state: StateFlow<DashboardState> =
        repo.billsFlow
            .map { bills -> bills.sumOf { it.amount } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)
            .let { expensesFlow ->
                repo.incomeFlow
                    .map { it?.monthlyIncome ?: 0.0 }
                    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)
                    .let { incomeFlow ->
                        repo.premiumFlow
                            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
                            .let { premiumFlow ->
                                // Combinar sin “combine” para mantenerlo simple aquí:
                                // (Luego lo refinamos)
                                premiumFlow.map { isPremium ->
                                    val income = incomeFlow.value
                                    val expenses = expensesFlow.value
                                    DashboardState(
                                        income = income,
                                        expenses = expenses,
                                        remaining = income - expenses,
                                        isPremium = isPremium
                                    )
                                }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardState())
                            }
                    }
            }

    fun setIncome(value: Double) {
        viewModelScope.launch { repo.setIncome(value) }
    }

    fun setPremium(enabled: Boolean) {
        viewModelScope.launch { repo.setPremium(enabled) }
    }

    fun addTestBill() {
        val dueTomorrow = System.currentTimeMillis() + TimeUnit.DAYS.toMillis(1)
        viewModelScope.launch {
            repo.addBill("Internet", 50.0, dueTomorrow)
        }
    }
}

