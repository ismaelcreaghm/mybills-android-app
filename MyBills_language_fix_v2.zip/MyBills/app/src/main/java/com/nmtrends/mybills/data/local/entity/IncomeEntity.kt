package com.nmtrends.mybills.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "income")
data class IncomeEntity(
    @PrimaryKey val key: Int = 0,
    val monthlyIncome: Double
)
