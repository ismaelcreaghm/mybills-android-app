package com.nmtrends.mybills.ui.notifications

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.nmtrends.mybills.ui.viewmodel.AppSettingsViewModel

@Composable
fun NotificationPermissionGate(
    vm: AppSettingsViewModel,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val notifAsked by vm.notifAsked.collectAsState()

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        // No hacemos nada aquí; si deniega, en Ajustes puede activarlo.
    }

    LaunchedEffect(notifAsked) {
        if (Build.VERSION.SDK_INT < 33) return@LaunchedEffect

        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED

        // ✅ Solo preguntar 1 vez
        if (!granted && !notifAsked) {
            vm.setNotifAsked(true) // marcar ANTES para evitar loops
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    content()
}

