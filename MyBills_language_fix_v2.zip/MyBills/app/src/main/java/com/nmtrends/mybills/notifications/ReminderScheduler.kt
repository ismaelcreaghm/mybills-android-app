package com.nmtrends.mybills.notifications

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit

object ReminderScheduler {

    private fun workName(billId: Long) = "bill_reminder_$billId"

    fun scheduleAt(
        context: Context,
        billId: Long,
        title: String,
        amount: Double,
        remindAtMillis: Long
    ) {
        val delay = (remindAtMillis - System.currentTimeMillis()).coerceAtLeast(0L)

        val data = workDataOf(
            "billId" to billId,
            "title" to title,
            "amount" to amount
        )

        val req = OneTimeWorkRequestBuilder<BillReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(data)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            workName(billId),
            ExistingWorkPolicy.REPLACE,
            req
        )
    }

    fun cancel(context: Context, billId: Long) {
        WorkManager.getInstance(context).cancelUniqueWork(workName(billId))
    }
}
