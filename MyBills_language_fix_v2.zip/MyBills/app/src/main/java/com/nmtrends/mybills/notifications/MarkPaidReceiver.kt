package com.nmtrends.mybills.notifications

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.nmtrends.mybills.di.ServiceLocator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MarkPaidReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()

        val billId = intent.getLongExtra("billId", -1L)
        val notifId = intent.getIntExtra("notifId", 0)

        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (billId > 0) {
                    val repo = ServiceLocator.provideRepository(context)
                    repo.markPaid(billId) // ✅ aquí estaba el problema
                }

                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (notifId != 0) nm.cancel(notifId)
            } finally {
                pending.finish()
            }
        }
    }
}
