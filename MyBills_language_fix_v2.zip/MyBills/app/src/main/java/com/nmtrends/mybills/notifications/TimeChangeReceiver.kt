package com.nmtrends.mybills.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

class TimeChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_TIME_CHANGED && action != Intent.ACTION_TIMEZONE_CHANGED) return

        val work = OneTimeWorkRequestBuilder<RescheduleWorker>().build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "reschedule_all",
            ExistingWorkPolicy.REPLACE,
            work
        )
    }
}
