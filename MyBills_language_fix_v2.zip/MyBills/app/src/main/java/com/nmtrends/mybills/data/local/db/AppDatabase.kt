package com.nmtrends.mybills.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.nmtrends.mybills.data.local.dao.BillDao
import com.nmtrends.mybills.data.local.dao.IncomeDao
import com.nmtrends.mybills.data.local.entity.BillEntity
import com.nmtrends.mybills.data.local.entity.IncomeEntity

@Database(
    entities = [BillEntity::class, IncomeEntity::class],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun billDao(): BillDao
    abstract fun incomeDao(): IncomeDao
}
