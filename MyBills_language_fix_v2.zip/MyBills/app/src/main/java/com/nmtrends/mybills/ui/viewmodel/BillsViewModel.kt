package com.nmtrends.mybills.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nmtrends.mybills.data.local.entity.BillEntity
import com.nmtrends.mybills.data.repository.BillsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BillsViewModel(private val repo: BillsRepository) : ViewModel() {

    val bills: StateFlow<List<BillEntity>> =
        repo.billsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isPremium: StateFlow<Boolean> =
        repo.premiumFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    fun addBill(
        title: String,
        amount: Double,
        dueDateMillis: Long,
        note: String?,
        reminderAtMillis: Long?,
        isMonthly: Boolean,
        dayOfMonth: Int?,
        reminderDaysBefore: Int?,
        reminderHour: Int?,
        reminderMinute: Int?,
        onLimitReached: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val result = repo.addBill(
                    title = title,
                    amount = amount,
                    dueDateMillis = dueDateMillis,
                    note = note,
                    reminderAtMillis = reminderAtMillis,
                    isMonthly = isMonthly,
                    dayOfMonth = dayOfMonth,
                    reminderDaysBefore = reminderDaysBefore,
                    reminderHour = reminderHour,
                    reminderMinute = reminderMinute
                )

                if (result.isSuccess) return@launch

                val msg = result.exceptionOrNull()?.message
                if (msg == "LIMIT_REACHED") onLimitReached()
                else onError(msg ?: "Error desconocido")
            } catch (e: Exception) {
                onError(e.message ?: "Error al guardar")
            }
        }
    }

    fun updateBill(
        id: Long,
        title: String,
        amount: Double,
        dueDateMillis: Long,
        note: String?,
        reminderAtMillis: Long?,
        isMonthly: Boolean,
        dayOfMonth: Int?,
        reminderDaysBefore: Int?,
        reminderHour: Int?,
        reminderMinute: Int?,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val result = repo.updateBill(
                    id = id,
                    title = title,
                    amount = amount,
                    dueDateMillis = dueDateMillis,
                    note = note,
                    reminderAtMillis = reminderAtMillis,
                    isMonthly = isMonthly,
                    dayOfMonth = dayOfMonth,
                    reminderDaysBefore = reminderDaysBefore,
                    reminderHour = reminderHour,
                    reminderMinute = reminderMinute
                )

                if (result.isFailure) {
                    onError(result.exceptionOrNull()?.message ?: "No se pudo editar")
                }
            } catch (e: Exception) {
                onError(e.message ?: "No se pudo editar")
            }
        }
    }

    fun deleteBill(bill: BillEntity, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                repo.deleteBill(bill)
            } catch (e: Exception) {
                onError(e.message ?: "No se pudo borrar")
            }
        }
    }

    fun undoDelete(bill: BillEntity, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val r = repo.restoreBill(bill)
                if (r.isFailure) onError(r.exceptionOrNull()?.message ?: "No se pudo restaurar")
            } catch (e: Exception) {
                onError(e.message ?: "No se pudo restaurar")
            }
        }
    }

    fun markPaid(bill: BillEntity, onMsg: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val r = repo.markPaid(bill.id)
                onMsg(if (r.isSuccess) "Marcada como pagada" else (r.exceptionOrNull()?.message ?: "No se pudo marcar"))
            } catch (e: Exception) {
                onMsg(e.message ?: "No se pudo marcar")
            }
        }
    }

    fun markUnpaid(bill: BillEntity, onMsg: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val r = repo.markUnpaid(bill.id)
                onMsg(if (r.isSuccess) "Marcada como no pagada" else (r.exceptionOrNull()?.message ?: "No se pudo marcar"))
            } catch (e: Exception) {
                onMsg(e.message ?: "No se pudo marcar")
            }
        }
    }

    fun moveBill(
        bill: BillEntity,
        direction: Int,
        currentList: List<BillEntity>,
        onError: (String) -> Unit = {}
    ) {
        if (direction == 0) return
        val index = currentList.indexOfFirst { it.id == bill.id }
        if (index == -1) return

        val newIndex = index + direction
        if (newIndex !in currentList.indices) return

        val a = currentList[index]
        val b = currentList[newIndex]

        viewModelScope.launch {
            try {
                repo.swapSortOrder(a.id, a.sortOrder, b.id, b.sortOrder)
            } catch (e: Exception) {
                onError(e.message ?: "No se pudo reordenar")
            }
        }
    }
}
