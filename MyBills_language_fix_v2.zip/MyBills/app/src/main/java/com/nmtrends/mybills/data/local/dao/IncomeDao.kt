package com.nmtrends.mybills.data.local.dao

import androidx.room.*
import com.nmtrends.mybills.data.local.entity.IncomeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface IncomeDao {

    @Query("SELECT * FROM income WHERE key = 0")
    fun observeIncome(): Flow<IncomeEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(income: IncomeEntity)
}
