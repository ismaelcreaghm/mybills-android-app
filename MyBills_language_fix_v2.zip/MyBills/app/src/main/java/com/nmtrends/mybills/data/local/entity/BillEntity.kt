package com.nmtrends.mybills.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bills")
data class BillEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,

    val title: String,
    val amount: Double,

    // Próximo vencimiento real (si es recurrente, este campo se recalcula)
    val dueDateMillis: Long,

    // Notas (Premium en UI; en DB puede existir pero tú decides mostrar/permitir)
    val note: String? = null,

    // Recordatorio exacto programado para este próximo vencimiento
    val reminderAtMillis: Long? = null,

    // Repetición (lo dejamos por compatibilidad con tu versión actual)
    val isMonthly: Boolean = false,
    val dayOfMonth: Int? = null,

    // Config Premium recordatorio relativo
    val reminderDaysBefore: Int? = null,
    val reminderHour: Int? = null,
    val reminderMinute: Int? = null,

    // Orden manual
    val sortOrder: Int = 0,

    // NUEVO: estado de pago
    val isPaid: Boolean = false,
    val paidAtMillis: Long? = null,

    // NUEVO: categoría (simple)
    val category: String? = null
)
