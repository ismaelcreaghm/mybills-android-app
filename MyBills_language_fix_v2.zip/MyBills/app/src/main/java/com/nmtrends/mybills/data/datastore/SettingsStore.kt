package com.nmtrends.mybills.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings_store")

enum class ThemeMode(val id: Int) {
    SYSTEM(0),
    LIGHT(1),
    DARK(2);

    companion object {
        fun fromId(id: Int): ThemeMode = values().firstOrNull { it.id == id } ?: SYSTEM
    }
}

class SettingsStore(private val context: Context) {

    private object Keys {
        val PREMIUM = booleanPreferencesKey("premium_enabled")
        val THEME_MODE = intPreferencesKey("theme_mode")

        // Idioma seleccionado por el usuario ("en" / "es")
        val LANGUAGE_TAG = stringPreferencesKey("language_tag")

        // ✅ NUEVO: si ya se pidió permiso de notificaciones (primer inicio)
        val NOTIF_ASKED = booleanPreferencesKey("notif_asked")
    }

    val premiumFlow: Flow<Boolean> =
        context.dataStore.data.map { prefs -> prefs[Keys.PREMIUM] ?: false }

    val themeModeFlow: Flow<ThemeMode> =
        context.dataStore.data.map { prefs ->
            ThemeMode.fromId(prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.id)
        }

    // ✅ NUEVO
    val notifAskedFlow: Flow<Boolean> =
        context.dataStore.data.map { prefs -> prefs[Keys.NOTIF_ASKED] ?: false }

    
// Idioma: null si aún no se eligió
val languageTagFlow: Flow<String?> =
    context.dataStore.data.map { prefs -> prefs[Keys.LANGUAGE_TAG] }

val languageChosenFlow: Flow<Boolean> =
    context.dataStore.data.map { prefs -> prefs[Keys.LANGUAGE_TAG] != null }

suspend fun setLanguageTag(tag: String) {
    context.dataStore.edit { prefs -> prefs[Keys.LANGUAGE_TAG] = tag }
}

suspend fun setPremium(enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[Keys.PREMIUM] = enabled }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { prefs -> prefs[Keys.THEME_MODE] = mode.id }
    }

    // ✅ NUEVO
    suspend fun setNotifAsked(asked: Boolean) {
        context.dataStore.edit { prefs -> prefs[Keys.NOTIF_ASKED] = asked }
    }
}
