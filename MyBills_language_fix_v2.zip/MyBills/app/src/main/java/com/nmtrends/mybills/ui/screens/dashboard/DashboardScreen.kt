package com.nmtrends.mybills.ui.screens.dashboard


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nmtrends.mybills.R
import com.nmtrends.mybills.di.ServiceLocator
import com.nmtrends.mybills.ui.viewmodel.DashboardViewModel
import com.nmtrends.mybills.ui.viewmodel.DashboardViewModelFactory
import java.text.NumberFormat
import kotlin.math.max
import com.nmtrends.mybills.ui.components.DonutChartCard
import com.nmtrends.mybills.ui.components.DonutSlice
import com.nmtrends.mybills.ui.components.DonutLegendItem
@Composable
fun DashboardScreen() {
    val context = LocalContext.current
    val repo = remember { ServiceLocator.provideRepository(context) }
    val vm: DashboardViewModel = viewModel(factory = DashboardViewModelFactory(repo))
    val state by vm.state.collectAsState()

    val scrollState = rememberScrollState()

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1) Summary
            Text(
                text = stringResource(R.string.dashboard_title),
                style = MaterialTheme.typography.headlineSmall
            )

            // 2) Chart (income, expenses, remaining)
            Text(
                text = stringResource(R.string.dashboard_chart),
                style = MaterialTheme.typography.titleMedium
            )
            val income = state.income
            val expenses = state.expenses
            val remaining = state.remaining

// Remaining solo positivo (si quieres mostrar negativo, lo tratamos después)
            val safeRemaining = if (remaining > 0) remaining else 0.0

            val expensesColor = MaterialTheme.colorScheme.primary
            val remainingColor = MaterialTheme.colorScheme.secondaryContainer // ✅ más claro y se diferencia bien

            DonutChartCard(
                centerMain = "$" + String.format(java.util.Locale.US, "%.0f", income),
                centerSub = "Income",
                slices = listOf(
                    DonutSlice(value = expenses.coerceAtLeast(0.0), color = expensesColor),
                    DonutSlice(value = safeRemaining.coerceAtLeast(0.0), color = remainingColor)
                ),
                legendItems = listOf(
                    DonutLegendItem("Income", income, MaterialTheme.colorScheme.tertiary),
                    DonutLegendItem("Expenses", expenses, expensesColor),
                    DonutLegendItem("Remaining", remaining, remainingColor)
                )
            )


            // 3) Monthly income (input + guardar)
            IncomeEditor(
                currentIncome = state.income,
                onSave = { vm.setIncome(it) }
            )

            // 4) Expenses (bills)
            SummaryCard(
                title = stringResource(R.string.dashboard_expenses_bills),
                value = state.expenses
            )

            // 5) Remaining
            SummaryCard(
                title = stringResource(R.string.dashboard_remaining),
                value = state.remaining
            )

            // 6) Premium yes/no
            Text(
                stringResource(
                    R.string.dashboard_premium_status,
                    if (state.isPremium) stringResource(R.string.yes) else stringResource(R.string.no)
                )
            )

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SummaryCard(title: String, value: Double) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            Text(value.toMoney(), style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun SimpleBars(income: Double, expenses: Double, remaining: Double) {
    val maxValue = max(1.0, max(income, max(expenses, kotlin.math.abs(remaining))))
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        BarRow(label = stringResource(R.string.dashboard_income), value = income, maxValue = maxValue)
        BarRow(label = stringResource(R.string.dashboard_expenses), value = expenses, maxValue = maxValue)
        BarRow(label = stringResource(R.string.dashboard_remaining), value = remaining, maxValue = maxValue)
    }
}

@Composable
private fun BarRow(label: String, value: Double, maxValue: Double) {
    val fraction = (kotlin.math.abs(value) / maxValue).coerceIn(0.0, 1.0).toFloat()

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.width(90.dp))

        Box(
            modifier = Modifier
                .height(18.dp)
                .weight(1f)
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction)
                    .background(MaterialTheme.colorScheme.primary)
            )
        }

        Spacer(Modifier.width(10.dp))
        Text(value.toMoney(), modifier = Modifier.width(90.dp))
    }
}

@Composable
private fun IncomeEditor(
    currentIncome: Double,
    onSave: (Double) -> Unit
) {
    var text by remember(currentIncome) {
        mutableStateOf(if (currentIncome == 0.0) "" else currentIncome.toString())
    }
    var error by remember { mutableStateOf<String?>(null) }

    val title = stringResource(R.string.dashboard_monthly_income)
    val hint = stringResource(R.string.dashboard_income_hint)
    val btn = stringResource(R.string.dashboard_save_income)
    val invalidMsg = stringResource(R.string.dashboard_invalid_number)

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = text,
                onValueChange = {
                    text = it
                    error = null
                },
                label = { Text(hint) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                isError = error != null,
                supportingText = { if (error != null) Text(error!!) },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    // Permite que el usuario escriba con coma o punto
                    val value = text.trim().replace(",", ".").toDoubleOrNull()
                    if (value == null || value < 0) {
                        error = invalidMsg
                        return@Button
                    }
                    onSave(value)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(btn)
            }
        }
    }
}

private fun Double.toMoney(): String {
    // Respeta el Locale del teléfono (español/inglés) para formato.
    return NumberFormat.getCurrencyInstance().format(this)
}
