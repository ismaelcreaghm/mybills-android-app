package com.nmtrends.mybills.util

enum class AppLanguage(val tag: String) {
    EN("en"),
    ES("es")
}
