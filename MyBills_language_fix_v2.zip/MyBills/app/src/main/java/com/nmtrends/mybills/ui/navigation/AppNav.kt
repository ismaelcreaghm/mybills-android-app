package com.nmtrends.mybills.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.nmtrends.mybills.ui.screens.bills.BillsScreen
import com.nmtrends.mybills.ui.screens.dashboard.DashboardScreen
import com.nmtrends.mybills.ui.screens.settings.SettingsScreen

@Composable
fun AppNav() {
    val nav = rememberNavController()

    Scaffold(
        bottomBar = { BottomBar(nav) }
    ) { innerPadding ->
        NavHost(
            navController = nav,
            startDestination = "dashboard",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("dashboard") { DashboardScreen() }
            composable("bills") { BillsScreen() }
            composable("settings") { SettingsScreen() }
        }
    }
}
