package com.nmtrends.mybills.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.nmtrends.mybills.MainActivity
import com.nmtrends.mybills.R
import java.util.Locale

class BillReminderWorker(
    private val context: Context,
    params: WorkerParameters
) : Worker(context, params) {

    override fun doWork(): Result {
        val billId = inputData.getLong("billId", -1L)
        val title = inputData.getString("title") ?: context.getString(R.string.notif_default_bill)
        val amount = inputData.getDouble("amount", 0.0)

        val channelId = "bills_reminders"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                context.getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.notif_channel_desc)
            }
            nm.createNotificationChannel(channel)
        }

        val notifId = if (billId > 0) (billId % Int.MAX_VALUE).toInt()
        else (System.currentTimeMillis() % Int.MAX_VALUE).toInt()

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else
            PendingIntent.FLAG_UPDATE_CURRENT

        // Abrir app
        val pkg = context.packageName

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            action = "$pkg.OPEN_APP_$billId"
        }
        val openAppPending = PendingIntent.getActivity(
            context,
            notifId + 1000,
            openAppIntent,
            flags
        )

        val amountText = String.format(Locale.US, "%.2f", amount)

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(context.getString(R.string.notif_reminder_title, title))
            .setContentText(context.getString(R.string.notif_reminder_amount, amountText))

            .setAutoCancel(true)
            .setContentIntent(openAppPending)
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        // Acción: marcar pagada
        if (billId > 0) {
            val markPaidIntent = Intent(context, MarkPaidReceiver::class.java).apply {
                action = "$pkg.MARK_PAID_$billId"
                putExtra("billId", billId)
                putExtra("notifId", notifId)
            }
            val markPaidPending = PendingIntent.getBroadcast(
                context,
                notifId,
                markPaidIntent,
                flags
            )

            builder.addAction(
                android.R.drawable.checkbox_on_background,
                context.getString(R.string.notif_mark_paid),
                markPaidPending
            )
        }

        nm.notify(notifId, builder.build())
        return Result.success()
    }
}
