package com.nmtrends.mybills.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.nmtrends.mybills.di.ServiceLocator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BillActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_MARK_PAID) return

        val billId = intent.getLongExtra(EXTRA_BILL_ID, -1L)
        if (billId <= 0) return

        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repo = ServiceLocator.provideRepository(context)
                repo.markPaid(billId)
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val ACTION_MARK_PAID = "com.nmtrends.mybills.ACTION_MARK_PAID"
        const val EXTRA_BILL_ID = "billId"
    }
}


