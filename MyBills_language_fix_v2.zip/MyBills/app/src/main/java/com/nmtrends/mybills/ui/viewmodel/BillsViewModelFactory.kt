package com.nmtrends.mybills.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.nmtrends.mybills.data.repository.BillsRepository

class BillsViewModelFactory(private val repo: BillsRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BillsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return BillsViewModel(repo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}


