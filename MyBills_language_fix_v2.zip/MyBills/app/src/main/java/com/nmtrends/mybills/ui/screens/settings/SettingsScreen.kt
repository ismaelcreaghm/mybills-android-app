package com.nmtrends.mybills.ui.screens.settings

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nmtrends.mybills.R
import com.nmtrends.mybills.data.datastore.ThemeMode
import com.nmtrends.mybills.di.ServiceLocator
import com.nmtrends.mybills.ui.viewmodel.AppSettingsViewModel
import com.nmtrends.mybills.ui.viewmodel.AppSettingsViewModelFactory
import com.nmtrends.mybills.util.AppLanguage

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val repo = remember { ServiceLocator.provideRepository(context) }
    val vm: AppSettingsViewModel = viewModel(factory = AppSettingsViewModelFactory(repo))

    val isPremium by vm.isPremium.collectAsState()
    val themeMode by vm.themeMode.collectAsState()
    val appLanguage by vm.appLanguage.collectAsState()

    var snackbarMsg by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMsg) {
        snackbarMsg?.let {
            snackbarHostState.showSnackbar(it)
            snackbarMsg = null
        }
    }

    // --- Support dialog state ---
    val supportEmail = "nmts6541@gmail.com"
    var showSupportDialog by remember { mutableStateOf(false) }

    // --- Strings ---
    val titleSettings = stringResource(R.string.settings_title)
    val langTitle = stringResource(R.string.language_title)
    val langEn = stringResource(R.string.language_english)
    val langEs = stringResource(R.string.language_spanish)

    val subscriptionTitle = stringResource(R.string.subscription_title)
    val premiumPrice = stringResource(R.string.premium_price)
    val premiumBenefitsTitle = stringResource(R.string.premium_benefits_title)

    val themeTitle = stringResource(R.string.theme_title)
    val currentModeFmt = stringResource(R.string.current_mode)
    val premiumOnlyHint = stringResource(R.string.theme_premium_only_hint)
    val themeSystem = stringResource(R.string.theme_system)
    val themeLight = stringResource(R.string.theme_light)
    val themeDark = stringResource(R.string.theme_dark)

    val notificationsTitle = stringResource(R.string.notifications_title)
    val enableNotifications = stringResource(R.string.enable_notifications)
    val notificationsNotRequired = stringResource(R.string.notifications_not_required)
    val notifEnabledMsg = stringResource(R.string.notifications_enabled_msg)
    val permissionDeniedMsg = stringResource(R.string.permission_denied_msg)
    val openAppSettingsLabel = stringResource(R.string.open_app_settings)

    val syncReminders = stringResource(R.string.sync_reminders)
    val syncDone = stringResource(R.string.sync_done)
    val syncFailed = stringResource(R.string.sync_failed)

    // Support strings
    val supportTitle = stringResource(R.string.support_title)
    val supportSendEmail = stringResource(R.string.support_send_email)
    val supportCopy = stringResource(R.string.support_copy)
    val supportCopied = stringResource(R.string.support_copied)
    val supportNoEmailApp = stringResource(R.string.support_no_email_app)
    val supportIconCd = stringResource(R.string.support_icon_cd)

    val hasNotifPermission = remember { mutableStateOf(checkNotificationsPermission(context)) }

    val notifLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotifPermission.value = granted
        snackbarMsg = if (granted) notifEnabledMsg else permissionDeniedMsg
    }

    val currentModeLabel = when (themeMode) {
        ThemeMode.SYSTEM -> themeSystem
        ThemeMode.LIGHT -> themeLight
        ThemeMode.DARK -> themeDark
    }

    val scrollState = rememberScrollState()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            // Header con botón soporte (?)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(titleSettings, style = MaterialTheme.typography.headlineSmall)

                IconButton(
                    onClick = { showSupportDialog = true },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.HelpOutline,
                        contentDescription = supportIconCd
                    )
                }
            }

            // --- Suscripción (todavía “manual”) ---
            // Más adelante: aquí reemplazaremos Switch por Billing real.
            Card {
                Column(
                    Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(subscriptionTitle, style = MaterialTheme.typography.titleMedium)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(premiumPrice, modifier = Modifier.weight(1f))
                        Switch(
                            checked = isPremium,
                            onCheckedChange = { vm.setPremium(it) }
                        )
                    }

                    Divider()

                    Text(premiumBenefitsTitle, style = MaterialTheme.typography.titleSmall)
                    Text(stringResource(R.string.benefit_1))
                    Text(stringResource(R.string.benefit_2))
                    Text(stringResource(R.string.benefit_3))
                    Text(stringResource(R.string.benefit_4))
                    Text(stringResource(R.string.benefit_5))
                    Text(stringResource(R.string.benefit_6))
                }
            }

            // --- Tema ---
            Card {
                Column(
                    Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(themeTitle, style = MaterialTheme.typography.titleMedium)

                    Text(
                        text = String.format(currentModeFmt, currentModeLabel),
                        style = MaterialTheme.typography.bodySmall
                    )

                    if (!isPremium) {
                        Text(premiumOnlyHint, style = MaterialTheme.typography.bodySmall)
                    }

                    ThemeOption(
                        label = themeSystem,
                        selected = themeMode == ThemeMode.SYSTEM,
                        enabled = true,
                        onClick = { vm.setThemeMode(ThemeMode.SYSTEM) }
                    )
                    ThemeOption(
                        label = themeLight,
                        selected = themeMode == ThemeMode.LIGHT,
                        enabled = isPremium,
                        onClick = { vm.setThemeMode(ThemeMode.LIGHT) }
                    )
                    ThemeOption(
                        label = themeDark,
                        selected = themeMode == ThemeMode.DARK,
                        enabled = isPremium,
                        onClick = { vm.setThemeMode(ThemeMode.DARK) }
                    )
                }
            }

            // --- Notificaciones ---
            Card {
                Column(
                    Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(notificationsTitle, style = MaterialTheme.typography.titleMedium)

                    if (Build.VERSION.SDK_INT >= 33) {
                        LaunchedEffect(Unit) {
                            hasNotifPermission.value = checkNotificationsPermission(context)
                        }

                        if (hasNotifPermission.value) {
                            Text(notifEnabledMsg, style = MaterialTheme.typography.bodySmall)
                        } else {
                            Button(
                                onClick = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(enableNotifications)
                            }

                            OutlinedButton(
                                onClick = { openAppSettings(context) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(openAppSettingsLabel)
                            }
                        }
                    } else {
                        Text(notificationsNotRequired, style = MaterialTheme.typography.bodySmall)
                    }

                    Divider()

                    Button(
                        onClick = {
                            vm.syncReminders { ok ->
                                snackbarMsg = if (ok) syncDone else syncFailed
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(syncReminders)
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }

    // --- Dialog Soporte ---
    if (showSupportDialog) {
        AlertDialog(
            onDismissRequest = { showSupportDialog = false },
            title = { Text(supportTitle) },
            text = { Text(supportEmail) },
            confirmButton = {
                Button(onClick = {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:$supportEmail")
                        putExtra(Intent.EXTRA_SUBJECT, "Soporte MyBills")
                    }
                    try {
                        context.startActivity(intent)
                    } catch (_: Exception) {
                        snackbarMsg = supportNoEmailApp
                    }
                    showSupportDialog = false
                }) {
                    Text(supportSendEmail)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Soporte MyBills", supportEmail))
                    snackbarMsg = supportCopied
                    showSupportDialog = false
                }) {
                    Text(supportCopy)
                }
            }
        )
    }
}

private fun checkNotificationsPermission(context: android.content.Context): Boolean {
    return if (Build.VERSION.SDK_INT >= 33) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }
}

private fun openAppSettings(context: android.content.Context) {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
        data = Uri.fromParts("package", context.packageName, null)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    context.startActivity(intent)
}

@Composable
private fun ThemeOption(
    label: String,
    selected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label)
        RadioButton(
            selected = selected,
            onClick = if (enabled) onClick else null,
            enabled = enabled
        )
    }
}
