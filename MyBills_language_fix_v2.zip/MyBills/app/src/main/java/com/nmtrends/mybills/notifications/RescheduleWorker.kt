package com.nmtrends.mybills.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.nmtrends.mybills.di.ServiceLocator

class RescheduleWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            val repo = ServiceLocator.provideRepository(applicationContext)
            repo.refreshAndRescheduleAll()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

