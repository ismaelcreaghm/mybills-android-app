package com.nmtrends.mybills.data.repository

import com.nmtrends.mybills.data.datastore.ThemeMode
import com.nmtrends.mybills.util.AppLanguage
import com.nmtrends.mybills.data.local.entity.BillEntity
import com.nmtrends.mybills.data.local.entity.IncomeEntity
import kotlinx.coroutines.flow.Flow

interface BillsRepository {
    val billsFlow: Flow<List<BillEntity>>
    val incomeFlow: Flow<IncomeEntity?>
    val premiumFlow: Flow<Boolean>
    val themeModeFlow: Flow<ThemeMode>

    // Idioma de la app (EN/ES)
    val appLanguageFlow: Flow<AppLanguage>
    val languageChosenFlow: Flow<Boolean>
    suspend fun setAppLanguage(language: AppLanguage)

    // NUEVO: si ya se pidió permiso de notificaciones (para primer inicio)
    val notifAskedFlow: Flow<Boolean>
    suspend fun setNotifAsked(asked: Boolean)

    suspend fun addBill(title: String, amount: Double, dueDateMillis: Long): Result<Long>

    suspend fun addBill(
        title: String,
        amount: Double,
        dueDateMillis: Long,
        note: String?,
        reminderAtMillis: Long?,
        isMonthly: Boolean,
        dayOfMonth: Int?,
        reminderDaysBefore: Int?,
        reminderHour: Int?,
        reminderMinute: Int?
    ): Result<Long>

    suspend fun updateBill(
        id: Long,
        title: String,
        amount: Double,
        dueDateMillis: Long,
        note: String?,
        reminderAtMillis: Long?,
        isMonthly: Boolean,
        dayOfMonth: Int?,
        reminderDaysBefore: Int?,
        reminderHour: Int?,
        reminderMinute: Int?
    ): Result<Unit>

    suspend fun markPaid(id: Long): Result<Unit>
    suspend fun markUnpaid(id: Long): Result<Unit>

    suspend fun restoreBill(bill: BillEntity): Result<Unit>

    suspend fun swapSortOrder(idA: Long, orderA: Int, idB: Long, orderB: Int)

    suspend fun deleteBill(bill: BillEntity)
    suspend fun setIncome(monthlyIncome: Double)
    suspend fun setPremium(enabled: Boolean)
    suspend fun setThemeMode(mode: ThemeMode)

    suspend fun refreshAndRescheduleAll()
}
