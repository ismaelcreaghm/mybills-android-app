package com.nmtrends.mybills.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nmtrends.mybills.data.datastore.ThemeMode
import com.nmtrends.mybills.util.AppLanguage
import com.nmtrends.mybills.data.repository.BillsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppSettingsViewModel(private val repo: BillsRepository) : ViewModel() {

    val themeMode: StateFlow<ThemeMode> =
        repo.themeModeFlow.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            ThemeMode.SYSTEM
        )

    val isPremium: StateFlow<Boolean> =
        repo.premiumFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val notifAsked: StateFlow<Boolean> =
        repo.notifAskedFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    
// Idioma
val appLanguage: StateFlow<AppLanguage> =
    repo.appLanguageFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppLanguage.EN)

val languageChosen: StateFlow<Boolean> =
    repo.languageChosenFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

fun setAppLanguage(language: AppLanguage) {
    viewModelScope.launch { repo.setAppLanguage(language) }
}

fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { repo.setThemeMode(mode) }
    }

    // OJO: esto más adelante lo vamos a reemplazar por Billing real.
    fun setPremium(value: Boolean) {
        viewModelScope.launch { repo.setPremium(value) }
    }

    fun setNotifAsked(value: Boolean) {
        viewModelScope.launch { repo.setNotifAsked(value) }
    }

    fun syncReminders(onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            try {
                repo.refreshAndRescheduleAll()
                onDone(true)
            } catch (_: Exception) {
                onDone(false)
            }
        }
    }
}
